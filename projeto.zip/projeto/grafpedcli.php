<?php
    include 'conecta.php';
    $sql = "SELECT 
            clientes.nome, 
            COUNT(pedidos.id_cliente) as total 
        FROM pedidos 
        INNER JOIN clientes ON pedidos.id_cliente = clientes.id 
        GROUP BY clientes.nome
        ORDER BY total DESC";
        $resultado = $conn->query($sql);
        $dados_grafico = [['Cliente', 'Total de Pedidos']];
        if ($resultado->num_rows > 0) {
            while($linha = $resultado->fetch_assoc()) {
                $dados_grafico[] = [$linha['nome'], (int)$linha['total']];
            }
        }
    $conn->close();
    $dados_json = json_encode($dados_grafico);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);
        function drawChart() {
            var data = google.visualization.arrayToDataTable(<?php echo $dados_json; ?>);
            var options = {
                width: 300,
                height: 150,
                bar: {groupWidth: "85%"},
                legend: { position: 'none' }
            };
            var chart = new google.visualization.ColumnChart(document.getElementById('grafico_coluna'));
            chart.draw(data, options);
        }
    </script>
  </head>
  <body>
    <div id="grafico_coluna" style="width: 300px; height: 150px;"></div>
  </body>
</html>